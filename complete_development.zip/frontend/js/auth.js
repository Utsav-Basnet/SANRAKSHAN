const userLoginForm = document.querySelector('#user-login-page form');
if (userLoginForm) {
  userLoginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = userLoginForm.querySelector('input[type="text"]')?.value;
    const password = userLoginForm.querySelector('input[type="password"]')?.value;
    if (!email || !password) {
      showNotification('Please fill in all fields', 'error');
      return;
    }
    try {
      const button = userLoginForm.querySelector('button');
      button.disabled = true;
      button.textContent = 'Logging in...';
      const data = await apiCall(API_ENDPOINTS.auth.login, {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      if (data.token) {
        localStorage.setItem('token', data.token);
        setUser({ email, role: data.role });
        showNotification('Login Successful!', 'success');
        setTimeout(() => { window.location.href = '/'; }, 1500);
      }
    } catch (error) {
      showNotification(error.message || 'Login failed', 'error');
    } finally {
      const button = userLoginForm.querySelector('button');
      button.disabled = false;
      button.textContent = 'Login';
    }
  });
}

const adminLoginForm = document.querySelector('#admin-login-page form');
if (adminLoginForm) {
  adminLoginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = adminLoginForm.querySelector('input[type="text"]')?.value;
    const password = adminLoginForm.querySelector('input[type="password"]')?.value;
    if (!email || !password) {
      showNotification('Please fill in all fields', 'error');
      return;
    }
    try {
      const button = adminLoginForm.querySelector('button');
      button.disabled = true;
      button.textContent = 'Logging in...';
      const data = await apiCall(API_ENDPOINTS.auth.login, {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      if (data.token && data.role === 'ADMIN') {
        localStorage.setItem('token', data.token);
        setUser({ email, role: data.role });
        showNotification('Admin Login Successful!', 'success');
        setTimeout(() => { window.location.href = '/'; }, 1500);
      } else {
        showNotification('Admin access required', 'error');
      }
    } catch (error) {
      showNotification(error.message || 'Login failed', 'error');
    } finally {
      const button = adminLoginForm.querySelector('button');
      button.disabled = false;
      button.textContent = 'Login';
    }
  });
}

function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.style.cssText = 'position: fixed; top: 20px; right: 20px; padding: 16px 24px; border-radius: 8px; font-weight: 600; z-index: 10000; color: white;';
  notification.style.background = type === 'success' ? '#2e7d32' : type === 'error' ? '#d32f2f' : '#1e6091';
  notification.textContent = message;
  document.body.appendChild(notification);
  setTimeout(() => notification.remove(), 3000);
}
